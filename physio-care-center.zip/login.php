<!DOCTYPE html>
<html lang='ar'>
<head>
<title>تسجيل الدخول</title>
<link href='assets/css/style.css' rel='stylesheet'>
</head>
<body>
<!-- نموذج تسجيل الدخول -->
</body>
</html>